/*
 * LEV Projects PS3 Edition 0.2
 * Native homebrew UI foundation for PlayStation 3 / PSL1GHT + Tiny3D.
 * This is an original native UI rewrite, not an HTML wrapper.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

#include <io/pad.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <tiny3d.h>
#include <libfont.h>

#include "lev_font_8x12.h"

#define SCREEN_W 848.0f
#define SCREEN_H 512.0f
#define CATEGORY_COUNT 5
#define MAX_TILES 5

#define COL_BG          0x07111fff
#define COL_BG2         0x0c1b2dff
#define COL_PANEL       0x10263beF
#define COL_PANEL_DARK  0x0a1929ff
#define COL_LINE        0x21425fff
#define COL_CYAN        0x37c8ffff
#define COL_CYAN_DARK   0x147daaff
#define COL_WHITE       0xf1f7ffff
#define COL_MUTED       0x9ab0c6ff
#define COL_GREEN       0x53e0b0ff
#define COL_ORANGE      0xffc36bff

static int g_running = 1;
static int g_category = 0;
static int g_tile = 0;
static int g_detail = 0;
static int g_info_overlay = 0;
static u32 *g_font_texture = NULL;

static const char *g_categories[CATEGORY_COUNT] = {
    "HOME", "PROJECTS", "ARCADE", "LEX AI", "ABOUT"
};

static const char *g_tiles[CATEGORY_COUNT][MAX_TILES] = {
    {"MY PROJECTS", "ARCADE", "LEX AI", "ABOUT", "SYSTEM INFO"},
    {"GRAND THEFT INDONESIA 5", "MINECERAFT", "ROOLOX", "BEDROCK EDITION", "EAGLERCRAFT"},
    {"TETRIS CLASSIC", "SKY HOP", "PIXEL QUEST", "RETRO RACER", "ARCADE INFO"},
    {"LEX AI 1.9.5", "LOCAL MODEL", "PORT STATUS", "CAPABILITIES", "LEX INFO"},
    {"LEV STUDIO", "CREDITS", "VERSION", "LICENSES", "ABOUT INFO"}
};

static const int g_tile_counts[CATEGORY_COUNT] = {5, 5, 5, 5, 5};

static const char *g_descriptions[CATEGORY_COUNT][MAX_TILES] = {
    {
      "Browse LEV projects and launch sections from one native hub.",
      "Open the arcade collection. Native mini-games are planned for 0.3.",
      "LEX AI 1.9.5 is listed here. Its JavaScript model still needs a native port.",
      "Created by LEV Studio. One hub. Many worlds.",
      "Native PlayStation 3 homebrew application. UI foundation 0.2."
    },
    {
      "Grand Theft Indonesia 5 - online project link is not launched in this offline build.",
      "Mineceraft LEV - project entry. A native PS3 game port is not included yet.",
      "ROOLOX - project entry. Runtime integration is planned for a later build.",
      "Mineceraft Bedrock Edition - project entry.",
      "Eaglercraft - project entry. Browser JavaScript cannot run directly as a PS3 app."
    },
    {
      "Tetris Classic - native mini-game module planned for LEV Projects 0.3.",
      "Sky Hop - native mini-game module planned for LEV Projects 0.3.",
      "Pixel Quest - native mini-game module planned for LEV Projects 0.3.",
      "Retro Racer - native mini-game module planned for LEV Projects 0.3.",
      "Arcade menu is native. Individual game modules come next."
    },
    {
      "LEX AI 1.9.5 from the web edition. This screen is a port-status placeholder.",
      "The original local neural n-gram model is JavaScript and browser-based.",
      "Native inference engine is not implemented in this 0.2 build.",
      "The original web edition includes offline helper tools and conversation memory.",
      "LEX AI will be handled as a separate native port milestone."
    },
    {
      "LEV Studio creates games and interactive projects.",
      "Conceptor and Architect: Maulana Al Fatih. Product Manager and Programmer: ChatGPT.",
      "LEV Projects PS3 Edition 0.2 - Native UI Foundation.",
      "PSL1GHT and Tiny3D remain external open-source development dependencies.",
      "A native PS3 application inspired by the LEV Projects web hub."
    }
};

static void sys_callback(u64 status, u64 param, void *userdata)
{
    (void)param;
    (void)userdata;
    if (status == SYSUTIL_EXIT_GAME) {
        g_running = 0;
    }
}

static void draw_rect(float x, float y, float w, float h, u32 color)
{
    tiny3d_SetPolygon(TINY3D_QUADS);
    tiny3d_VertexPos(x,     y,     65535);
    tiny3d_VertexColor(color);
    tiny3d_VertexPos(x + w, y,     65535);
    tiny3d_VertexPos(x + w, y + h, 65535);
    tiny3d_VertexPos(x,     y + h, 65535);
    tiny3d_End();
}

static void draw_text(float x, float y, int width, int height, u32 color, const char *value)
{
    SetCurrentFont(0);
    SetFontSize(width, height);
    SetFontColor(color, 0x00000000);
    DrawString(x, y, value);
}

static void draw_background(void)
{
    int i;
    draw_rect(0, 0, SCREEN_W, SCREEN_H, COL_BG);
    draw_rect(0, 0, SCREEN_W, 3, COL_CYAN_DARK);
    for (i = 0; i < 12; ++i) {
        float x = (float)(i * 83 - 120);
        draw_rect(x, 58, 1, 385, 0x0c2134ff);
    }
    draw_rect(0, 444, SCREEN_W, 68, 0x050c16ff);
    draw_rect(0, 444, SCREEN_W, 1, COL_LINE);
}

static void draw_header(void)
{
    int i;
    draw_rect(34, 20, 42, 31, COL_CYAN);
    draw_text(43, 27, 12, 17, 0x06111cff, "L");
    draw_text(88, 22, 13, 18, COL_WHITE, "LEV PROJECTS");
    draw_text(89, 43, 7, 10, COL_MUTED, "PLAYSTATION 3 EDITION  /  0.2 NATIVE UI");

    draw_text(612, 23, 8, 12, COL_MUTED, "HEN HOMEbrew");
    draw_text(612, 42, 7, 10, COL_GREEN, "CONTROLLER READY");

    for (i = 0; i < CATEGORY_COUNT; ++i) {
        float x = 34.0f + (float)i * 157.0f;
        u32 c = (i == g_category) ? COL_CYAN : COL_MUTED;
        if (i == g_category) {
            draw_rect(x, 91, 120, 3, COL_CYAN);
            draw_rect(x, 96, 120, 29, 0x12334aff);
        }
        draw_text(x + 8, 102, 8, 12, c, g_categories[i]);
    }
}

static void draw_tile_card(int index, float x, float y, int selected)
{
    u32 accent = selected ? COL_CYAN : COL_LINE;
    u32 body = selected ? 0x153954ff : COL_PANEL_DARK;
    char number[8];
    draw_rect(x, y, 145, 126, body);
    draw_rect(x, y, 145, 2, accent);
    draw_rect(x, y + 2, 1, 124, 0x1a3850ff);
    draw_rect(x + 12, y + 15, 37, 37, selected ? COL_CYAN_DARK : 0x193149ff);
    snprintf(number, sizeof(number), "%02d", index + 1);
    draw_text(x + 20, y + 26, 11, 16, COL_WHITE, number);
    {
        const char *label = g_tiles[g_category][index];
        if (g_category == 1) {
            static const char *short_projects[MAX_TILES] = {"GT INDONESIA 5", "MINECERAFT", "ROOLOX", "BEDROCK", "EAGLERCRAFT"};
            label = short_projects[index];
        }
        draw_text(x + 12, y + 67, 7, 11, selected ? COL_WHITE : COL_MUTED, label);
    }
    draw_text(x + 12, y + 105, 6, 9, selected ? COL_CYAN : 0x6e8aa4ff, selected ? "SELECTED" : "OPEN WITH X");
    if (selected) {
        draw_rect(x + 5, y + 5, 135, 1, COL_CYAN);
        draw_rect(x + 5, y + 5, 1, 116, COL_CYAN);
        draw_rect(x + 139, y + 5, 1, 116, COL_CYAN);
        draw_rect(x + 10, y + 122, 125, 3, COL_CYAN);
    }
}

static void draw_home_content(void)
{
    int i;
    float start = 42.0f;
    draw_text(43, 151, 9, 13, COL_CYAN, "WELCOME BACK");
    draw_text(42, 174, 24, 34, COL_WHITE, "ONE HUB. MANY WORLDS.");
    draw_text(43, 218, 8, 12, COL_MUTED, "Your LEV projects, arcade collection and AI workspace in one place.");
    draw_rect(42, 252, 765, 1, COL_LINE);
    for (i = 0; i < g_tile_counts[g_category]; ++i) {
        draw_tile_card(i, start + (float)i * 153.0f, 278, i == g_tile);
    }
    draw_text(43, 420, 7, 10, COL_MUTED, "QUICK ACCESS  /  PICK A CARD WITH LEFT OR RIGHT, THEN PRESS X");
}

static void draw_regular_content(void)
{
    int i;
    float start = 42.0f;
    draw_text(43, 151, 9, 13, COL_CYAN, "LEV PROJECTS / NATIVE HUB");
    draw_text(42, 176, 22, 31, COL_WHITE, g_categories[g_category]);
    draw_text(43, 218, 8, 12, COL_MUTED,
              g_category == 1 ? "Your game worlds and interactive projects." :
              g_category == 2 ? "Small games, big nostalgia. Arcade ports are next." :
              g_category == 3 ? "A separate milestone for the LEX AI native engine." :
              "Studio information, version and project credits.");
    draw_rect(42, 252, 765, 1, COL_LINE);
    for (i = 0; i < g_tile_counts[g_category]; ++i) {
        draw_tile_card(i, start + (float)i * 153.0f, 278, i == g_tile);
    }
}

static void draw_detail(void)
{
    const char *title = g_tiles[g_category][g_tile];
    const char *desc = g_descriptions[g_category][g_tile];
    draw_rect(42, 142, 765, 274, COL_PANEL_DARK);
    draw_rect(42, 142, 765, 3, COL_CYAN);
    draw_text(66, 166, 8, 12, COL_CYAN, "ITEM DETAILS");
    draw_text(65, 199, 18, 26, COL_WHITE, title);
    draw_rect(66, 240, 710, 1, COL_LINE);
    draw_text(66, 264, 9, 14, COL_MUTED, desc);
    draw_text(66, 329, 8, 12, COL_ORANGE, "STATUS: PORT IN PROGRESS");
    draw_text(66, 370, 8, 12, COL_MUTED, "PRESS CIRCLE TO RETURN TO THE HUB");
}

static void draw_info_overlay(void)
{
    draw_rect(142, 146, 564, 230, 0x0a1b2dfF);
    draw_rect(142, 146, 564, 3, COL_CYAN);
    draw_text(168, 173, 12, 17, COL_WHITE, "LEV PROJECTS PS3 EDITION");
    draw_text(168, 210, 8, 12, COL_MUTED, "0.2 NATIVE UI FOUNDATION");
    draw_text(168, 246, 8, 12, COL_WHITE, "D-PAD LEFT / RIGHT  -  MOVE THROUGH CARDS");
    draw_text(168, 269, 8, 12, COL_WHITE, "L1 / R1  -  CHANGE CATEGORY");
    draw_text(168, 292, 8, 12, COL_WHITE, "CROSS  -  OPEN DETAILS     CIRCLE  -  BACK");
    draw_text(168, 338, 7, 10, COL_CYAN, "THIS IS A NATIVE PORT FOUNDATION, NOT THE FINAL GAME HUB.");
}

static void draw_footer(void)
{
    draw_text(36, 462, 7, 10, COL_WHITE, "X  SELECT");
    draw_text(148, 462, 7, 10, COL_WHITE, "O  BACK");
    draw_text(247, 462, 7, 10, COL_WHITE, "L1 / R1  CATEGORY");
    draw_text(401, 462, 7, 10, COL_WHITE, "START  HOME");
    draw_text(36, 488, 6, 9, COL_MUTED, "LEV STUDIO  |  NATIVE HOMEbrew  |  PSL1GHT + TINY3D");
    draw_text(665, 488, 6, 9, COL_MUTED, "ONE HUB. MANY WORLDS.");
}

static void render_frame(void)
{
    tiny3d_Clear(COL_BG, TINY3D_CLEAR_ALL);
    tiny3d_Project2D();
    draw_background();
    draw_header();
    if (g_detail) draw_detail();
    else if (g_category == 0) draw_home_content();
    else draw_regular_content();
    if (g_info_overlay) draw_info_overlay();
    draw_footer();
    tiny3d_Flip();
}

static void handle_pad(void)
{
    padData pad;
    if (ioPadGetData(0, &pad) != 0 || pad.len == 0) return;

    if (g_info_overlay) {
        if (pad.BTN_CIRCLE || pad.BTN_CROSS) g_info_overlay = 0;
        return;
    }
    if (pad.BTN_START) {
        g_category = 0;
        g_tile = 0;
        g_detail = 0;
    }
    if (pad.BTN_L1) {
        g_category = (g_category + CATEGORY_COUNT - 1) % CATEGORY_COUNT;
        g_tile = 0;
        g_detail = 0;
    }
    if (pad.BTN_R1) {
        g_category = (g_category + 1) % CATEGORY_COUNT;
        g_tile = 0;
        g_detail = 0;
    }
    if (pad.BTN_LEFT && !g_detail) {
        g_tile = (g_tile + g_tile_counts[g_category] - 1) % g_tile_counts[g_category];
    }
    if (pad.BTN_RIGHT && !g_detail) {
        g_tile = (g_tile + 1) % g_tile_counts[g_category];
    }
    if (pad.BTN_CROSS && !g_detail) g_detail = 1;
    if (pad.BTN_CIRCLE) {
        if (g_detail) g_detail = 0;
        else if (g_category != 0) { g_category = 0; g_tile = 0; }
    }
    if (pad.BTN_TRIANGLE) g_info_overlay = 1;
}

int main(int argc, char *argv[])
{
    (void)argc;
    (void)argv;

    if (tiny3d_Init(1024 * 1024) < 0) {
        sysProcessExit(1);
        return 1;
    }

    ioPadInit(7);
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, sys_callback, NULL);

    g_font_texture = (u32 *)tiny3d_AllocTexture(1024 * 1024);
    if (g_font_texture) {
        ResetFont();
        AddFontFromBitmapArray((u8 *)lev_font_8x12, (u8 *)g_font_texture,
                               32, 126, 8, 12, 1, BIT7_FIRST_PIXEL);
        SetCurrentFont(0);
        SetFontSize(8, 12);
        SetFontColor(COL_WHITE, 0x00000000);
    }

    while (g_running) {
        sysUtilCheckCallback();
        handle_pad();
        render_frame();
        usleep(16000);
    }

    sysUtilUnregisterCallback(SYSUTIL_EVENT_SLOT0);
    ioPadEnd();
    tiny3d_Exit();
    sysProcessExit(0);
    return 0;
}
