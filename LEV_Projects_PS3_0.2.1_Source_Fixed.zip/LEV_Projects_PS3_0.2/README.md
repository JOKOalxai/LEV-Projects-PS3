# LEV Projects PS3 Edition 0.2.1 — Native UI Foundation Build Fixes

This is the first native PlayStation 3 source port of the LEV Projects hub concept. It is written in C for PSL1GHT and uses Tiny3D/libfont for its 2D interface.

## What works in this milestone

- Native PS3 application entry point (not an HTML/WebView wrapper).
- Dark LEV visual theme with cyan accents and XMB-inspired horizontal category strip.
- Categories: Home, Projects, Arcade, LEX AI, About.
- Project entries: Grand Theft Indonesia 5, Mineceraft, ROOLOX, Bedrock Edition and Eaglercraft.
- Arcade entries: Tetris Classic, Sky Hop, Pixel Quest and Retro Racer.
- DualShock 3 input: D-pad left/right changes selected cards; L1/R1 changes categories; Cross opens details; Circle goes back; Triangle opens controls; Start returns Home.
- Package metadata and icon for a homebrew PKG build.

## Not included yet

- The original JavaScript/HTML game runtime is not embedded. Browser projects need separate native ports or a compatible runtime; this app currently lists them as project entries.
- Arcade titles are menu entries only in 0.2. Native mini-game modules are planned for 0.3.
- LEX AI 1.9.5 is not yet ported. Its model and storage layer are browser JavaScript and need a dedicated native implementation.
- This source archive is not a compiled `.pkg`. A successful toolchain build is required before installing it on the console.

## Build from GitHub Actions on a Chromebook

1. Create a **new** GitHub repository, for example `LEV-Projects-PS3` (keep it separate from the LEV Neural Graphics repository).
2. Upload this ZIP file itself to the repository root: `LEV_Projects_PS3_0.2.1_Source_Fixed.zip`.
3. In GitHub, choose **Add file → Create new file** and name it `.github/workflows/build.yml`.
4. Copy the workflow content from the matching `.github/workflows/build.yml` file in this source ZIP and paste it into GitHub. Commit the new file. This revision fixes the Tiny3D library search paths and uses the PS3DEV Docker image from a hosted Ubuntu runner. This revision runs checkout on the GitHub runner, builds inside the PS3DEV Docker image, and includes the Tiny3D portlibs paths in the Makefile.
5. Open **Actions** and run **Build LEV Projects PS3 PKG**.
6. If the run succeeds, download the artifact `LEV-Projects-PS3-0.2-PKG`.

The workflow uses a PS3 development container, installs Tiny3D/libfont, extracts this source ZIP, compiles the app, runs `make pkg`, and uploads the package artifact.

## Controls

| DualShock 3 | Action |
|---|---|
| D-pad Left / Right | Move between cards |
| L1 / R1 | Switch category |
| Cross (X) | Open details |
| Circle (O) | Back |
| Triangle | Controls overlay |
| Start | Home |

## Build identity

- App title: LEV Projects PS3 Edition
- APPID: `LEVPS3001`
- Content ID: `UP0001-LEVPS3001_00-0000000000000000`
- Version: 0.2 Native UI Foundation

## Credits and dependency notices

- LEV Projects concept and product direction: LEV Studio.
- PSL1GHT: https://github.com/ps3dev/PSL1GHT (MIT license).
- Tiny3D: https://github.com/granberro/tiny3d (see upstream repository for its licensing notes).
- Embedded bitmap font generated from DejaVu Sans Mono; see `DEJAVU_FONT_LICENSE.txt`.

This is an independent homebrew project and is not affiliated with or endorsed by Sony Interactive Entertainment.
